const io = require("socket.io-client");
const readline = require("readline");
const crypto = require("crypto");

const socket = io("http://localhost:3000");

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
    prompt: "> ",
});

let username = "";

function hashMessage(msg) {
    return crypto.createHash("sha256").update(msg, "utf8").digest("hex");
}

socket.on("connect", () => {
    console.log("Connected to the server");

    rl.question("Enter your username: ", (input) => {
        username = input.trim() || "Anonymous";
        console.log(`Welcome, ${username} to the chat`);
        rl.prompt();

        rl.on("line", (message) => {
            const trimmed = message.trim();
            if (trimmed) {
                const h = hashMessage(trimmed);
                socket.emit("message", { username, message: trimmed, hash: h });
            }
            rl.prompt();
        });
    });
});

socket.on("message", (data) => {
    const { username: senderUsername, message: senderMessage, hash: sentHash } = data;

    if (senderUsername === username) {
        return rl.prompt();
    }

    if (sentHash) {
        const recomputed = hashMessage(senderMessage);
        if (recomputed !== sentHash) {
            console.log(`\nWARNING: message from ${senderUsername} may have been changed during transmission!`);
            console.log(`  Received message (modified): ${senderMessage}`);
            console.log(`  Sent HASH: ${sentHash}`);
            console.log(`  Computed HASH: ${recomputed}`);
            rl.prompt();
            return;
        }
    }

    console.log(`${senderUsername}: ${senderMessage}`);
    rl.prompt();
});

socket.on("disconnect", () => {
    console.log("Server disconnected, Exiting...");
    rl.close();
    process.exit(0);
});

rl.on("SIGINT", () => {
    console.log("\nExiting...");
    socket.disconnect();
    rl.close();
    process.exit(0);
});
