const io = require("socket.io-client");
const readline = require("readline");
const crypto = require("crypto");

const socket = io("http://localhost:3000");

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
    prompt: "> ",
});

let registeredUsername = "";
let currentClaim = "";
const users = new Map();

const { publicKey, privateKey } = crypto.generateKeyPairSync("rsa", {
    modulusLength: 2048,
    publicKeyEncoding: { type: "spki", format: "pem" },
    privateKeyEncoding: { type: "pkcs8", format: "pem" },
});

function signMessage(claimedUsername, message) {
    const payload = `${claimedUsername}:${message}`;
    const sign = crypto.createSign("sha256");
    sign.update(payload);
    sign.end();
    return sign.sign(privateKey, "base64");
}

function verifySignature(publicKeyPem, claimedUsername, message, signatureBase64) {
    const payload = `${claimedUsername}:${message}`;
    const verify = crypto.createVerify("sha256");
    verify.update(payload);
    verify.end();
    try {
        return verify.verify(publicKeyPem, signatureBase64, "base64");
    } catch (e) {
        return false;
    }
}

socket.on("connect", () => {
    console.log("Connected to the server");

    rl.question("Enter your username: ", (input) => {
        registeredUsername = input.trim() || "Anonymous";
        currentClaim = registeredUsername;
        console.log(`Welcome, ${registeredUsername} to the chat`);

        socket.emit("registerPublicKey", {
            username: registeredUsername,
            publicKey: publicKey,
        });

        rl.prompt();

        rl.on("line", (line) => {
            const message = line.trim();
            if (!message) {
                rl.prompt();
                return;
            }

            const impersonateMatch = message.match(/^!impersonate (\w+)$/);
            if (impersonateMatch) {
                currentClaim = impersonateMatch[1];
                console.log(`Now impersonating as ${currentClaim}`);
                rl.prompt();
                return;
            }

            if (message === "!exit") {
                currentClaim = registeredUsername;
                console.log(`Stopped impersonation. Now you are ${registeredUsername}`);
                rl.prompt();
                return;
            }

            const signature = signMessage(currentClaim, message);
            socket.emit("message", {
                claimedUsername: currentClaim,
                message,
                signature,
            });

            rl.prompt();
        });
    });
});

socket.on("init", (entries) => {
    entries.forEach(([user, key]) => users.set(user, key));
    console.log(`\nThere are currently ${users.size} users in the chat`);
    rl.prompt();
});

socket.on("newUser", (data) => {
    const { username, publicKey } = data;
    users.set(username, publicKey);
    console.log(`${username} joined the chat`);
    rl.prompt();
});

socket.on("message", (data) => {
    const { claimedUsername, message, signature } = data;

    if (claimedUsername === registeredUsername && currentClaim === registeredUsername) {
        rl.prompt();
        return;
    }

    const pubKey = users.get(claimedUsername);
    if (!pubKey) {
        console.log(`${claimedUsername}: ${message} [unknown user / no public key]`);
        rl.prompt();
        return;
    }

    const valid = verifySignature(pubKey, claimedUsername, message, signature);
    if (!valid) {
        socket.emit("warning", {
            claimedUsername,
            message
        });
    } else {
        console.log(`${claimedUsername}: ${message}`);
    }
    rl.prompt();
});

socket.on("warning", (data) => {
    console.log(`${data.claimedUsername}: ${data.message} [this user is fake]`);
    rl.prompt();
});

socket.on("disconnect", () => {
    console.log("Server disconnected, Exiting...");
    rl.close();
    process.exit(0);
});

rl.on("SIGINT", () => {
    console.log("\nExiting...");
    socket.disconnect();
    rl.close();
    process.exit(0);
});
