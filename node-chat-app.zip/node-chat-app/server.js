const http = require("http");
const socketIo = require("socket.io");

const server = http.createServer();
const io = socketIo(server);

const users = new Map();
const userSockets = new Map();

io.on("connection", (socket) => {
    console.log(`Client ${socket.id} connected`);

    socket.emit("init", Array.from(users.entries()));

    socket.on("registerPublicKey", (data) => {
        const { username, publicKey } = data;
        users.set(username, publicKey);
        userSockets.set(username, socket.id);
        console.log(`${username} registered with public key.`);
        io.emit("newUser", { username, publicKey });
    });

    socket.on("message", (data) => {
        const { username, message, encrypted, target } = data;

        if (encrypted && target) {
            const targetSocketId = userSockets.get(target);
            if (targetSocketId) {
                io.to(targetSocketId).emit("message", { username, message, encrypted, target });
            }
        } else {
            io.emit("message", { username, message, encrypted: false });
        }
    });

    socket.on("warning", (data) => {
        io.emit("warning", data);
    });

    socket.on("disconnect", () => {
        console.log(`Client ${socket.id} disconnected`);
        for (const [username, socketId] of userSockets.entries()) {
            if (socketId === socket.id) {
                userSockets.delete(username);
                break;
            }
        }
    });
});

const port = 3000;
server.listen(port, () => {
    console.log(`Server running on port ${port}`);
});
